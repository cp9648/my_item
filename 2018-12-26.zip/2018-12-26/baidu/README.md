```
scrapy startproject baidu
cd baidu

scrapy genspider StarSpider index.baidu.com

scrapy crawl StarSpider
```